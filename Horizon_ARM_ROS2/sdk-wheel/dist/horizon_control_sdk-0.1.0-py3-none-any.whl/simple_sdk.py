#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
SimpleArmSDK: 面向上层应用的简易封装（“防君子”级别）

功能要点：
- 统一连接（SLCAN 串口或 SocketCAN）
- 批量使能/失能/停止/同步
- 绝对/相对到位（输出端角或电机角）
- 力矩模式（电流mA）与退出
- 读取实测角度（可选换算为输出端角）

依赖：
- 在运行前将本目录加入 PYTHONPATH（示例）
  export PYTHONPATH=$HOME/Horizon_ARM/Control_SDK-ros:$PYTHONPATH
"""

from __future__ import annotations

from typing import List, Optional, Sequence, Tuple
import time

from Control_Core.motor_controller_modular import ZDTMotorControllerModular  # type: ignore


class SimpleArmSDK:
    """六轴机械臂的简易 SDK 封装。

    参数中 `sign/gear_ratio/zero_offset_deg/send_space` 用于角度换算：
    - send_space == "motor": 接口下发接受电机角；提供输出端角会自动按映射转换
    - send_space == "output": 接口下发接受输出端角；提供电机角会原样下发
    """

    def __init__(
        self,
        motor_ids: Sequence[int],
        port_or_channel: str,
        *,
        bitrate: int = 500000,
        sign: Sequence[int] | None = None,
        gear_ratio: Sequence[float] | None = None,
        zero_offset_deg: Sequence[float] | None = None,
        send_space: str = "motor",
    ) -> None:
        self.motor_ids: List[int] = list(motor_ids)
        self.port_or_channel: str = str(port_or_channel)
        self.bitrate: int = int(bitrate)
        self.interface_type: str = (
            "socketcan" if self.port_or_channel.lower().startswith("can") else "slcan"
        )

        self.sign: List[int] = list(sign or [1, 1, 1, 1, 1, 1])
        self.gear_ratio: List[float] = list(gear_ratio or [1.0, 1.0, 1.0, 1.0, 1.0, 1.0])
        self.zero_offset_deg: List[float] = list(zero_offset_deg or [0, 0, 0, 0, 0, 0])
        self.send_space: str = str(send_space).strip().lower()

        self.ctrls: List[ZDTMotorControllerModular] = []
        self.bc: Optional[ZDTMotorControllerModular] = None
        self.connected: bool = False

    # ---------- 角度换算 ----------
    def output_to_motor_deg(self, out_deg: Sequence[float]) -> List[float]:
        vals: List[float] = []
        for i, v in enumerate(out_deg):
            direction = self.sign[i] if i < len(self.sign) else 1
            ratio = self.gear_ratio[i] if i < len(self.gear_ratio) else 1.0
            zero = self.zero_offset_deg[i] if i < len(self.zero_offset_deg) else 0.0
            vals.append(direction * float(v) * ratio + zero)
        return vals

    # ---------- 连接/断开 ----------
    def connect(self, enable: bool = True) -> None:
        if self.connected:
            return
        kwargs = {}
        if self.interface_type == "socketcan":
            kwargs = {"interface_type": "socketcan", "channel": self.port_or_channel, "bitrate": self.bitrate}
        else:
            kwargs = {"interface_type": "slcan", "port": self.port_or_channel, "baudrate": self.bitrate}

        # 广播控制器（用于 sync_motion/stop 等）
        self.bc = ZDTMotorControllerModular(motor_id=0, **kwargs)
        self.bc.connect()

        self.ctrls = []
        for mid in self.motor_ids:
            c = ZDTMotorControllerModular(motor_id=int(mid), **kwargs)
            c.connect()
            if enable:
                try:
                    c.control_actions.enable(multi_sync=False)
                except Exception:
                    pass
            self.ctrls.append(c)
            time.sleep(0.05)
        self.connected = True

    def close(self, disable: bool = False) -> None:
        if not self.connected:
            return
        for c in self.ctrls:
            try:
                if disable:
                    c.control_actions.disable()
            except Exception:
                pass
            try:
                c.disconnect()
            except Exception:
                pass
        if self.bc:
            try:
                if disable:
                    self.bc.control_actions.disable()
            except Exception:
                pass
            try:
                self.bc.disconnect()
            except Exception:
                pass
        self.ctrls.clear()
        self.bc = None
        self.connected = False

    # ---------- 便捷控制 ----------
    def enable_all(self) -> None:
        for c in self.ctrls:
            try:
                c.control_actions.enable(multi_sync=False)
            except Exception:
                pass

    def disable_all(self) -> None:
        for c in self.ctrls:
            try:
                c.control_actions.disable(multi_sync=False)
            except Exception:
                pass

    def stop_all(self) -> None:
        for c in self.ctrls:
            try:
                c.control_actions.stop(multi_sync=False)
            except Exception:
                pass

    def sync(self) -> None:
        if self.bc:
            try:
                self.bc.control_actions.sync_motion()
            except Exception:
                pass

    # ---------- 到位控制 ----------
    def goto_output_abs(self, output_deg: Sequence[float], *, max_speed_rpm: float, acc: int, dec: int) -> None:
        """一次性到位：以输出端角为目标（内部按映射换算电机角并绝对到位）。"""
        motor_deg = self.output_to_motor_deg(output_deg) if self.send_space == "motor" else list(output_deg)
        for c, pos in zip(self.ctrls, motor_deg):
            try:
                c.control_actions.move_to_position_trapezoid(
                    position=float(pos), max_speed=float(max_speed_rpm), acceleration=int(acc), deceleration=int(dec),
                    is_absolute=True, multi_sync=True
                )
            except Exception:
                pass
        self.sync()

    def goto_output_rel(self, delta_output_deg: Sequence[float], *, max_speed_rpm: float, acc: int, dec: int) -> None:
        """一次性相对到位：以输出端角增量为目标（内部换算电机角相对到位）。"""
        motor_delta: List[float] = []
        for i, d in enumerate(delta_output_deg):
            direction = self.sign[i] if i < len(self.sign) else 1
            ratio = self.gear_ratio[i] if i < len(self.gear_ratio) else 1.0
            motor_delta.append(direction * float(d) * ratio if self.send_space == "motor" else float(d))
        for c, d in zip(self.ctrls, motor_delta):
            try:
                c.control_actions.move_to_position_trapezoid(
                    position=float(d), max_speed=float(max_speed_rpm), acceleration=int(acc), deceleration=int(dec),
                    is_absolute=False, multi_sync=True
                )
            except Exception:
                pass
        self.sync()

    def nudge_single_output(self, joint_index: int, delta_out_deg: float, *, max_speed_rpm: float, acc: int, dec: int) -> None:
        """单轴相对微调（输出端角增量）。"""
        if joint_index < 0 or joint_index >= len(self.ctrls):
            return
        direction = self.sign[joint_index] if joint_index < len(self.sign) else 1
        ratio = self.gear_ratio[joint_index] if joint_index < len(self.gear_ratio) else 1.0
        delta_motor = direction * float(delta_out_deg) * ratio if self.send_space == "motor" else float(delta_out_deg)
        try:
            self.ctrls[joint_index].control_actions.move_to_position_trapezoid(
                position=float(delta_motor), max_speed=float(max_speed_rpm), acceleration=int(acc), deceleration=int(dec),
                is_absolute=False, multi_sync=False
            )
        except Exception:
            pass

    def servo_step_output(self, delta_out_each: Sequence[float], *, max_speed_rpm: float, acc: int, dec: int) -> None:
        """实时伺服步进：按每轴输出端角增量相对下发，并触发多轴同步。"""
        motor_delta: List[float] = []
        for i, d in enumerate(delta_out_each):
            direction = self.sign[i] if i < len(self.sign) else 1
            ratio = self.gear_ratio[i] if i < len(self.gear_ratio) else 1.0
            motor_delta.append(direction * float(d) * ratio if self.send_space == "motor" else float(d))
        for c, d in zip(self.ctrls, motor_delta):
            if abs(d) < 1e-9:
                continue
            try:
                c.control_actions.move_to_position_trapezoid(
                    position=float(d), max_speed=float(max_speed_rpm), acceleration=int(acc), deceleration=int(dec),
                    is_absolute=False, multi_sync=True
                )
            except Exception:
                pass
        self.sync()

    def servo_step_output_direct(self, delta_out_each: Sequence[float], *, speed_rpm, acc: int, dec: int) -> None:
        """实时伺服步进（直通速度模式）：按每轴输出端角增量相对下发，随后多轴同步。

        speed_rpm 可以是 float（对所有轴相同）或 Sequence[float]（逐轴速度RPM）。
        """
        # 归一化 per-axis 速度
        speed_each: List[float]
        try:
            # 若为序列，逐轴取值
            speed_each = [float(speed_rpm[i]) for i in range(len(self.ctrls))]
        except Exception:
            # 单值广播
            speed_each = [float(speed_rpm) for _ in self.ctrls]

        motor_delta: List[float] = []
        for i, d in enumerate(delta_out_each):
            direction = self.sign[i] if i < len(self.sign) else 1
            ratio = self.gear_ratio[i] if i < len(self.gear_ratio) else 1.0
            motor_delta.append(direction * float(d) * ratio if self.send_space == "motor" else float(d))
        for idx, (c, d) in enumerate(zip(self.ctrls, motor_delta)):
            if abs(d) < 1e-9:
                continue
            spd = float(speed_each[idx]) if idx < len(speed_each) else float(speed_each[-1])
            try:
                c.control_actions.move_to_position(
                    position=float(d), speed=spd, is_absolute=False, multi_sync=True
                )
            except Exception:
                # 直通失败时退回梯形
                try:
                    c.control_actions.move_to_position_trapezoid(
                        position=float(d), max_speed=spd, acceleration=int(acc), deceleration=int(dec),
                        is_absolute=False, multi_sync=True
                    )
                except Exception:
                    pass
            # 适当节流，降低总线拥塞
            time.sleep(0.01)
        self.sync()

    # ---------- 力矩模式 ----------
    def set_torque_all(self, current_ma: int, current_slope: int = 500) -> None:
        for c in self.ctrls:
            try:
                c.control_actions.set_torque(int(current_ma), int(current_slope), multi_sync=False)
            except Exception:
                pass

    # ---------- 读取/状态 ----------
    def read_positions_output(self) -> List[float]:
        """读取实测角并转换为输出端角（度）。失败的轴返回 nan。"""
        out: List[float] = []
        for i, c in enumerate(self.ctrls):
            try:
                pos_motor = float(c.read_parameters.get_position())
                direction = self.sign[i] if i < len(self.sign) else 1
                ratio = self.gear_ratio[i] if i < len(self.gear_ratio) else 1.0
                pos_out = (pos_motor * direction) / (ratio if ratio else 1.0)
                out.append(pos_out)
            except Exception:
                out.append(float("nan"))
            time.sleep(0.02)
        return out

    # ---------- 上下文管理 ----------
    def __enter__(self) -> "SimpleArmSDK":
        self.connect(enable=True)
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close(disable=False)


__all__ = ["SimpleArmSDK"]


